/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ridercoder.ridercodereview;
import org.springframework.data.jpa.repository.JpaRepository;
/**
 *
 * @author kenne
 */
public interface RiderRepository extends JpaRepository<Rider, Long> {
    
}
